package com.example.btdoorlock1104

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Log
import androidx.appcompat.app.AppCompatActivity

@SuppressLint("CustomSplashScreen")
class SplashActivity : AppCompatActivity() {

    private lateinit var bluetoothService: BluetoothService

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_splash)

        bluetoothService = BluetoothService(this,
            updateBluetoothStatus = { /* 빈 람다로 전달 */ },
            onAuthenticationSuccess = { /* 빈 람다로 전달 */ }
        )

        bluetoothService.connect()
        if (bluetoothService.isConnected()) {
            bluetoothService.sendMessage("CONNECTED")
            Log.d("SplashActivity", "Bluetooth connected and message sent to Arduino.")
        } else {
            Log.d("SplashActivity", "Bluetooth not connected.")
        }

        Handler(Looper.getMainLooper()).postDelayed({
            startActivity(Intent(this, MainActivity::class.java))
            finish()
        }, 2000)
    }
}
