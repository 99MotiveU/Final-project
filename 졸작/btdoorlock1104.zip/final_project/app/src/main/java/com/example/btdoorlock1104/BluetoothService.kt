package com.example.btdoorlock1104

import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothSocket
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.util.Log
import android.widget.Toast
import androidx.core.content.ContextCompat
import java.io.IOException
import java.util.UUID

class BluetoothService(
    private val context: Context,
    private val updateBluetoothStatus: (Boolean) -> Unit,
    private val onAuthenticationSuccess: (Boolean) -> Unit  // 인증 성공 시 호출할 콜백 함수
) {
    private val bluetoothAdapter: BluetoothAdapter? = BluetoothAdapter.getDefaultAdapter()
    private var bluetoothSocket: BluetoothSocket? = null
    private var isConnected = false
    private val hc06Uuid: UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB") // HC-06 UUID
    private val deviceName = "HC-06"

    init {
        if (bluetoothAdapter == null) {
            Log.e("BluetoothService", "Bluetooth is not supported on this device.")
        }
    }

    private fun checkPermissions(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            ContextCompat.checkSelfPermission(context, android.Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED &&
                    ContextCompat.checkSelfPermission(context, android.Manifest.permission.BLUETOOTH_SCAN) == PackageManager.PERMISSION_GRANTED
        } else {
            ContextCompat.checkSelfPermission(context, android.Manifest.permission.BLUETOOTH) == PackageManager.PERMISSION_GRANTED &&
                    ContextCompat.checkSelfPermission(context, android.Manifest.permission.BLUETOOTH_ADMIN) == PackageManager.PERMISSION_GRANTED
        }
    }

    @SuppressLint("MissingPermission")
    fun connect() {
        if (!checkPermissions()) {
            Toast.makeText(context, "Bluetooth permissions are required.", Toast.LENGTH_SHORT).show()
            return
        }

        if (bluetoothAdapter == null || !bluetoothAdapter.isEnabled) {
            Log.e("BluetoothService", "Bluetooth is not available or not enabled.")
            return
        }

        val pairedDevices: Set<BluetoothDevice>? = bluetoothAdapter.bondedDevices
        val device = pairedDevices?.find { it.name == deviceName }

        if (device != null) {
            try {
                bluetoothSocket = device.createRfcommSocketToServiceRecord(hc06Uuid)
                bluetoothAdapter.cancelDiscovery()
                bluetoothSocket?.connect()
                isConnected = true
                Log.d("BluetoothService", "Bluetooth connected.")

                // 연결된 후 "CONNECTED" 메시지 전송
                sendMessage("CONNECTED")

                // Bluetooth 상태 업데이트
                updateBluetoothStatus(true)

            } catch (e: IOException) {
                e.printStackTrace()
                Log.e("BluetoothService", "Failed to connect to the device.", e)
                isConnected = false
                updateBluetoothStatus(false)
            }
        } else {
            Log.e("BluetoothService", "Device not found in paired devices.")
            updateBluetoothStatus(false)
        }
    }

    fun isConnected(): Boolean {
        return isConnected && bluetoothSocket?.isConnected == true
    }

    fun sendMessage(message: String) {
        if (isConnected()) {
            try {
                Log.d("BluetoothService", "Attempting to send message: $message")
                bluetoothSocket?.outputStream?.write(message.toByteArray())
                Log.d("BluetoothService", "Message sent: $message")

                // 예시로 "U" 메시지가 성공적으로 보내졌다면 인증 성공을 알리기 위해 호출
                if (message == "U") {
                    onAuthenticationSuccess(true)  // 인증 성공
                }

                // 예시로 "L" 메시지가 성공적으로 보내졌다면 인증 실패를 알리기 위해 호출
                if (message == "L") {
                    onAuthenticationSuccess(false)  // 인증 실패
                }

            } catch (e: IOException) {
                e.printStackTrace()
                Log.e("BluetoothService", "Failed to send message.")
            }
        } else {
            Log.e("BluetoothService", "Not connected to Bluetooth.")
        }
    }
}
