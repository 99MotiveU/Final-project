package com.example.btdoorlock1104

import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {

    private lateinit var bluetoothService: BluetoothService
    private lateinit var fingerprintButton: Button
    private lateinit var lockStatusTextView: TextView
    private lateinit var bluetoothStatusTextView: TextView
    private var isUnlocked = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        bluetoothStatusTextView = findViewById(R.id.bluetoothStatus)
        fingerprintButton = findViewById(R.id.fingerprintButton)
        lockStatusTextView = findViewById(R.id.lockStatus)

        bluetoothService = BluetoothService(
            this,
            updateBluetoothStatus = { isConnected ->
                bluetoothStatusTextView.text = if (isConnected) "Bluetooth : 연결됨" else "Bluetooth : 연결 안됨"
            },
            onAuthenticationSuccess = { success ->
                if (success) {
                    lockStatusTextView.text = "현재 상태 : 열림"
                    isUnlocked = true
                } else {
                    lockStatusTextView.text = "현재 상태 : 닫힘"
                    isUnlocked = false
                }
            }
        )

        bluetoothService.connect()

        fingerprintButton.setOnClickListener {
            startFingerprintAuthentication()
        }
    }

    private fun startFingerprintAuthentication() {
        val biometricPrompt = BiometricPrompt(
            this,
            ContextCompat.getMainExecutor(this),
            object : BiometricPrompt.AuthenticationCallback() {
                override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                    super.onAuthenticationSucceeded(result)
                    Log.d("Fingerprint", "Authentication succeeded")
                    toggleLockStatus()
                }

                override fun onAuthenticationFailed() {
                    super.onAuthenticationFailed()
                    Log.d("Fingerprint", "Authentication failed")
                }

                override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                    super.onAuthenticationError(errorCode, errString)
                    Log.e("Fingerprint", "Authentication error: $errString")
                }
            }
        )

        val promptInfo = BiometricPrompt.PromptInfo.Builder()
            .setTitle("지문 인증")
            .setSubtitle("지문을 인증하여 잠금을 해제하거나 잠금하세요")
            .setNegativeButtonText("취소")
            .build()

        biometricPrompt.authenticate(promptInfo)
    }

    private fun toggleLockStatus() {
        if (isUnlocked) {
            bluetoothService.sendMessage("L")
            lockStatusTextView.text = "Door Locked"
            isUnlocked = false
        } else {
            bluetoothService.sendMessage("U")
            lockStatusTextView.text = "Door Unlocked"
            isUnlocked = true
        }
    }
}
