package com.example.bluetoothsolenoid

import android.Manifest
import android.bluetooth.BluetoothAdapter
import android.content.Context
import android.bluetooth.BluetoothSocket
import android.content.pm.PackageManager
import android.util.Log
import androidx.core.app.ActivityCompat
import java.io.IOException
import java.util.UUID

class BluetoothConnection(private val mContext: Context ) {
//    private static final String TAG = "BluetoothConnection"

    private val bluetoothAdapter:BluetoothAdapter? = BluetoothAdapter.getDefaultAdapter()
    private var bluetoothSocket:BluetoothSocket? = null
    private val uuid:UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB") // 표주ㅠㄴ SerialPortService ID

    fun connect(deviceAddress: String): Boolean {
        if(bluetoothAdapter == null){
            Log.e("BluetoothConnection", "블루투스를 지원하지 않는 기기입니다.")
            return false
        }
        if (!bluetoothAdapter.isEnabled) {
            Log.e("BluetoothConnection", "블루투스가 비활성화되어 있습니다.")
        }

        val device = bluetoothAdapter.getRemoteDevice(deviceAddress)
        try{

            if (ActivityCompat.checkSelfPermission(
                    mContext,
                    Manifest.permission.BLUETOOTH_CONNECT
                ) != PackageManager.PERMISSION_GRANTED
            ) {
                // TODO: Consider calling
                //    ActivityCompat#requestPermissions
                // here to request the missing permissions, and then overriding
                //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
                //                                          int[] grantResults)
                // to handle the case where the user grants the permission. See the documentation
                // for ActivityCompat#requestPermissions for more details.
                return false
            }
            bluetoothSocket = device.createRfcommSocketToServiceRecord(uuid)
            bluetoothSocket?.connect()
            Log.d("BluetoothConnection", "블루투스 연결 성공")
            return true
        }catch (e:Exception){
            Log.e("BluetoothConnection", "블루투스 연결 실패: ${e.message}")
            try {
                bluetoothSocket?.close()
            }catch (closeException:Exception){
                Log.e("BluetoothConnection", "블루투스 소켓 닫기 실패: ${closeException.message}")
            }
            return false
        }
    }

    fun disconnect(){
        try {
            bluetoothSocket?.close()
            Log.d("BluetoothConnection", "블루투스 연결 해제")
        }catch (e:Exception){
            Log.e("BluetoothConnection", "블루투스 연결 해제 실패: ${e.message}")
        }
    }


    fun sendData(data:String){
        try {
            bluetoothSocket?.outputStream?.write(data.toByteArray())
            Log.d("BluetoothConnection", "데이터 전송 성공: $data")
        } catch (e: IOException) {
            Log.e("BluetoothConnection", "데이터 전송 실패: ${e.message}")

        }
    }

    // 데이터 수신 메서드 (별도의 스레드에서 실행해야 함)
    fun receiveData(): String? {
        val buffer = ByteArray(1024)
        var bytes: Int
        var message = ""
        try {
            bytes = bluetoothSocket?.inputStream?.read(buffer) ?: -1
            if (bytes != -1) {
                message = String(buffer, 0, bytes)
                Log.d("BluetoothConnection", "데이터 수신 성공: $message")
            }
        } catch (e: IOException) {
            Log.e("BluetoothConnection", "데이터 수신 실패", e)
        }
        return message
    }
}