package com.example.bluetoothsolenoid


import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {
    private lateinit var authenticateButton: Button
    private lateinit var biometricPrompt: BiometricPrompt
    private lateinit var promptInfo: BiometricPrompt.PromptInfo

    val bluetoothConnection: BluetoothConnection = BluetoothConnection(this)
    val deviceAddress: String = "00:11:22:33:44:55" // 연결하는 기기의 MAC 주소

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        setupBiometricAuthentication()

        authenticateButton = findViewById(R.id.authenticate_button)
        authenticateButton.setOnClickListener {
            //authenticateUser(this)
            biometricPrompt.authenticate(promptInfo)
        }

        // 블루투스
        if (!bluetoothConnection.connect(deviceAddress)) {
            // 연결 실패
            Toast.makeText(this, "블루투스 연결 실패", Toast.LENGTH_SHORT).show()
        }else{
            // 연결 성공
            bluetoothConnection.sendData("Hello, Bluetooth!")
            // 연결 성공 후 작업 수행
            val receiveData = bluetoothConnection.receiveData()
            Toast.makeText(this, "블루투스 연결 성공", Toast.LENGTH_SHORT).show()
        }
        
    }

    private fun setupBiometricAuthentication() {
        val executor = ContextCompat.getMainExecutor(this)
        biometricPrompt = BiometricPrompt(this, executor,
            object : BiometricPrompt.AuthenticationCallback(){
                override fun onAuthenticationError(
                    errorCode: Int,
                    errString: CharSequence
                ) {
                    super.onAuthenticationError(errorCode, errString)
                    Toast.makeText(applicationContext, "인증 오류: $errString", Toast.LENGTH_SHORT).show()
                }

                override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                    super.onAuthenticationSucceeded(result)
                    // 인증 성공 후 작업 수행
                    Toast.makeText(applicationContext, "인증 성공", Toast.LENGTH_SHORT).show()
                }

                override fun onAuthenticationFailed() {
                    super.onAuthenticationFailed()
                    Toast.makeText(applicationContext, "인증 실패", Toast.LENGTH_SHORT).show()
                }
            })
        promptInfo = BiometricPrompt.PromptInfo.Builder()
            .setTitle("생체 인증")
            .setSubtitle("기기에 등록된 생체 정보를 사용하여 인증해 주세요.")
            .setNegativeButtonText("취소")
            .build()
    }


    override fun onDestroy(){
        super.onDestroy()
        bluetoothConnection.disconnect()
    }

}