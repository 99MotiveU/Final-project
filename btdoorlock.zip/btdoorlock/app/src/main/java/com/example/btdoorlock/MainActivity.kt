package com.example.btdoorlock

import android.Manifest
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothSocket
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import java.io.IOException
import java.io.InputStream
import java.util.*

class MainActivity : AppCompatActivity() {

    private var bluetoothAdapter: BluetoothAdapter? = null
    private var bluetoothSocket: BluetoothSocket? = null
    private var inputStream: InputStream? = null

    // HC-05 블루투스 모듈의 UUID
    private val MY_UUID: UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")
    // 실제 블루투스 장치 주소로 변경하세요.
    private val deviceAddress = "00:00:00:00:00"

    private lateinit var connectButton: Button
    private lateinit var disconnectButton: Button
    private lateinit var bluetoothStatus: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // UI 요소들 초기화
        connectButton = findViewById(R.id.connectButton)
        disconnectButton = findViewById(R.id.disconnectButton)
        bluetoothStatus = findViewById(R.id.bluetoothStatus)

        // 블루투스 어댑터 초기화
        bluetoothAdapter = BluetoothAdapter.getDefaultAdapter()

        // 블루투스 기능이 있는지 확인
        if (bluetoothAdapter == null) {
            bluetoothStatus.text = "Bluetooth is not supported on this device"
            return
        }

        // 블루투스 활성화 상태 확인
        if (!bluetoothAdapter!!.isEnabled) {
            // 블루투스를 활성화하는 요청
            val enableBtIntent = Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE)
            if (ActivityCompat.checkSelfPermission(
                    this,
                    Manifest.permission.BLUETOOTH_CONNECT
                ) != PackageManager.PERMISSION_GRANTED
            ) {
                // TODO: Consider calling
                //    ActivityCompat#requestPermissions
                // here to request the missing permissions, and then overriding
                //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
                //                                          int[] grantResults)
                // to handle the case where the user grants the permission. See the documentation
                // for ActivityCompat#requestPermissions for more details.
                return
            }
            startActivityForResult(enableBtIntent, 1)
        }

        // 연결 버튼 클릭 시
        connectButton.setOnClickListener {
            connectToBluetoothDevice(deviceAddress)
        }

        // 해제 버튼 클릭 시
        disconnectButton.setOnClickListener {
            disconnectBluetooth()
        }
    }

    // 블루투스 장치에 연결하는 함수
    private fun connectToBluetoothDevice(address: String) {
        val device: BluetoothDevice = bluetoothAdapter!!.getRemoteDevice(address)

        try {
            if (ActivityCompat.checkSelfPermission(
                    this,
                    Manifest.permission.BLUETOOTH_CONNECT
                ) != PackageManager.PERMISSION_GRANTED
            ) {
                // TODO: Consider calling
                //    ActivityCompat#requestPermissions
                // here to request the missing permissions, and then overriding
                //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
                //                                          int[] grantResults)
                // to handle the case where the user grants the permission. See the documentation
                // for ActivityCompat#requestPermissions for more details.
                return
            }
            bluetoothSocket = device.createRfcommSocketToServiceRecord(MY_UUID)
            bluetoothSocket!!.connect()
            Toast.makeText(this, "Connected to Bluetooth", Toast.LENGTH_SHORT).show()

            // 연결이 완료되면 데이터를 수신할 준비
            inputStream = bluetoothSocket!!.inputStream
            listenForData()
        } catch (e: IOException) {
            e.printStackTrace()
            Toast.makeText(this, "Connection failed", Toast.LENGTH_SHORT).show()
        }
    }

    // 블루투스 연결 해제
    private fun disconnectBluetooth() {
        try {
            bluetoothSocket?.close()
            Toast.makeText(this, "Disconnected from Bluetooth", Toast.LENGTH_SHORT).show()
        } catch (e: IOException) {
            e.printStackTrace()
        }
    }

    // 블루투스에서 데이터를 수신하는 함수
    private fun listenForData() {
        val buffer = ByteArray(1024)
        var bytes: Int

        val workerThread = Thread {
            while (!Thread.currentThread().isInterrupted) {
                try {
                    // 데이터 수신 시 처리
                    if (inputStream?.available() ?: 0 > 0) {
                        bytes = inputStream!!.read(buffer)
                        val data = String(buffer, 0, bytes)

                        runOnUiThread {
                            bluetoothStatus.text = "Received data: $data"
                        }
                    }
                } catch (e: IOException) {
                    e.printStackTrace()
                }
            }
        }
        workerThread.start()
    }
}

