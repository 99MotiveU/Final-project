package com.example.btdoorlock1104

import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothSocket
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.util.Log
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import java.io.IOException
import java.util.UUID

class BluetoothService(
    private val context: Context,
    private val updateBluetoothStatus: (Boolean) -> Unit,
    private val onAuthenticationSuccess: (Boolean) -> Unit
) {
    private val bluetoothAdapter: BluetoothAdapter? = BluetoothAdapter.getDefaultAdapter()
    private var bluetoothSocket: BluetoothSocket? = null
    private var isConnected = false
    private val hc06Uuid: UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB") // HC-06 UUID
    private val deviceName = "HC-06"

    init {
        if (bluetoothAdapter == null) {
            Log.e("BluetoothService", "Bluetooth is not supported on this device.")
        }
    }

    private fun checkPermissions(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            ContextCompat.checkSelfPermission(context, android.Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED &&
                    ContextCompat.checkSelfPermission(context, android.Manifest.permission.BLUETOOTH_SCAN) == PackageManager.PERMISSION_GRANTED
        } else {
            ContextCompat.checkSelfPermission(context, android.Manifest.permission.BLUETOOTH) == PackageManager.PERMISSION_GRANTED &&
                    ContextCompat.checkSelfPermission(context, android.Manifest.permission.BLUETOOTH_ADMIN) == PackageManager.PERMISSION_GRANTED
        }
    }

    @SuppressLint("MissingPermission")
    fun connect() {
        if (!checkPermissions()) {
            Toast.makeText(context, "Bluetooth permissions are required.", Toast.LENGTH_SHORT).show()
            return
        }

        if (bluetoothAdapter == null || !bluetoothAdapter.isEnabled) {
            Log.e("BluetoothService", "Bluetooth is not available or not enabled.")
            return
        }

        val pairedDevices: Set<BluetoothDevice>? = bluetoothAdapter.bondedDevices
        val device = pairedDevices?.find { it.name == deviceName }

        if (device != null) {
            try {
                bluetoothSocket = device.createRfcommSocketToServiceRecord(hc06Uuid)
                bluetoothAdapter.cancelDiscovery()
                bluetoothSocket?.connect()
                isConnected = true
                Log.d("BluetoothService", "Bluetooth connected.")
                sendMessage("CONNECTED")
                updateBluetoothStatus(true)
                listenForMessages()
            } catch (e: IOException) {
                e.printStackTrace()
                Log.e("BluetoothService", "Failed to connect to the device.", e)
                isConnected = false
                updateBluetoothStatus(false)
            }
        } else {
            Log.e("BluetoothService", "Device not found in paired devices.")
            updateBluetoothStatus(false)
        }
    }

    fun isConnected(): Boolean {
        return isConnected && bluetoothSocket?.isConnected == true
    }

    fun sendMessage(message: String) {
        if (isConnected()) {
            try {
                bluetoothSocket?.outputStream?.write(message.toByteArray())
                Log.d("BluetoothService", "Message sent: $message")
            } catch (e: IOException) {
                e.printStackTrace()
                Log.e("BluetoothService", "Failed to send message.")
            }
        } else {
            Log.e("BluetoothService", "Not connected to Bluetooth.")
        }
    }

    private fun listenForMessages() {
        Thread {
            try {
                while (isConnected()) {
                    val message = bluetoothSocket?.inputStream?.bufferedReader()?.readLine()
                    if (message != null) {
                        Log.d("BluetoothService", "Received message: $message")
                        (context as? AppCompatActivity)?.runOnUiThread {
                            when (message) {
                                "CONNECTED" -> updateBluetoothStatus(true)
                                "U" -> onAuthenticationSuccess(true)
                                "L" -> onAuthenticationSuccess(false)
                            }
                        }
                    }
                }
            } catch (e: IOException) {
                Log.e("BluetoothService", "Error receiving data", e)
            }
        }.start()
    }
}
