package com.example.btdoorlock1104

import android.Manifest
import android.bluetooth.BluetoothAdapter
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.biometric.BiometricPrompt
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {

    private lateinit var bluetoothService: BluetoothService
    private lateinit var fingerprintButton: Button
    private lateinit var lockStatusTextView: TextView
    private lateinit var bluetoothStatusTextView: TextView
    private lateinit var lockButton: Button
    private var isUnlocked = false
    private val bluetoothAdapter: BluetoothAdapter? = BluetoothAdapter.getDefaultAdapter()
    private val handler = Handler(Looper.getMainLooper()) // 타이머를 위한 핸들러

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        supportActionBar?.hide()

        // UI 초기화
        bluetoothStatusTextView = findViewById(R.id.bluetoothStatus)
        fingerprintButton = findViewById(R.id.fingerprintButton)
        lockStatusTextView = findViewById(R.id.lockStatus)
        lockButton = findViewById(R.id.lockButton)

        // BluetoothService 초기화
        bluetoothService = BluetoothService(
            this,
            updateBluetoothStatus = { isConnected ->
                bluetoothStatusTextView.text = if (isConnected) "Bluetooth : 연결됨" else "Bluetooth : 연결 안됨"
                if (isConnected) {
                    bluetoothService.sendMessage("CONNECTED")
                }
            },
            onAuthenticationSuccess = { success ->
                if (success) unlockDoor()
            }
        )

        // Bluetooth 권한 확인 및 요청
        if (!checkBluetoothPermissions()) {
            requestBluetoothPermissions()
        } else {
            setupBluetooth()
        }

        // 지문 인증 버튼 클릭 리스너
        fingerprintButton.setOnClickListener {
            startFingerprintAuthentication()
        }

        // 잠금 버튼 클릭 리스너
        lockButton.setOnClickListener {
            lockDoor()
        }
    }

    private fun unlockDoor() {
        isUnlocked = true
        lockStatusTextView.text = "현재 상태 : 열림"
        bluetoothService.sendMessage("U") // 아두이노에 Unlock 명령 전송

        // 10초 후 자동으로 잠금 상태로 변경
        handler.postDelayed({
            if (isUnlocked) {
                lockDoor()
            }
        }, 10000) // 10,000ms = 10초
    }

    private fun lockDoor() {
        if (bluetoothService.isConnected()) {
            isUnlocked = false
            lockStatusTextView.text = "현재 상태 : 잠김"
            bluetoothService.sendMessage("L") // 아두이노에 Lock 명령 전송
        } else {
            Toast.makeText(this, "Bluetooth가 연결되지 않았습니다.", Toast.LENGTH_SHORT).show()
        }
    }

    private fun startFingerprintAuthentication() {
        val biometricPrompt = BiometricPrompt(
            this,
            ContextCompat.getMainExecutor(this),
            object : BiometricPrompt.AuthenticationCallback() {
                override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                    unlockDoor()
                }
            }
        )

        val promptInfo = BiometricPrompt.PromptInfo.Builder()
            .setTitle("지문 인증")
            .setSubtitle("잠금을 해제하거나 잠금합니다.")
            .setNegativeButtonText("취소")
            .build()

        biometricPrompt.authenticate(promptInfo)
    }

    private fun checkBluetoothPermissions(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            ActivityCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED &&
                    ActivityCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_SCAN) == PackageManager.PERMISSION_GRANTED
        } else {
            ActivityCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH) == PackageManager.PERMISSION_GRANTED &&
                    ActivityCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_ADMIN) == PackageManager.PERMISSION_GRANTED
        }
    }

    private fun requestBluetoothPermissions() {
        val permissions = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            arrayOf(Manifest.permission.BLUETOOTH_CONNECT, Manifest.permission.BLUETOOTH_SCAN)
        } else {
            arrayOf(Manifest.permission.BLUETOOTH, Manifest.permission.BLUETOOTH_ADMIN)
        }

        ActivityCompat.requestPermissions(this, permissions, REQUEST_BLUETOOTH_PERMISSION)
    }

    private fun setupBluetooth() {
        if (bluetoothAdapter == null) {
            Toast.makeText(this, "Bluetooth를 지원하지 않는 기기입니다.", Toast.LENGTH_SHORT).show()
            return
        }

        if (!bluetoothAdapter.isEnabled) {
            val enableBtIntent = Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE)
            enableBluetooth.launch(enableBtIntent)
        } else {
            connectBluetooth()
        }
    }

    private val enableBluetooth =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == RESULT_OK) {
                connectBluetooth()
            } else {
                Toast.makeText(this, "Bluetooth가 활성화되지 않았습니다.", Toast.LENGTH_SHORT).show()
            }
        }

    private fun connectBluetooth() {
        val macAddress = "98:DA:60:0B:9A:DA" // HC-06 MAC 주소
        bluetoothService.connectWithMacAddress(macAddress)
    }

    companion object {
        const val REQUEST_BLUETOOTH_PERMISSION = 1
    }
}
