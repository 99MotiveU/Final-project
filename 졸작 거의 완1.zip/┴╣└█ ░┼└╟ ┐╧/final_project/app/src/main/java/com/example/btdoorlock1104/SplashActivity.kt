package com.example.btdoorlock1104

import android.annotation.SuppressLint
import android.os.Bundle
import android.view.animation.Animation
import android.view.animation.AnimationUtils
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import android.content.Intent
import android.os.Handler
import android.os.Looper

@SuppressLint("CustomSplashScreen")
class SplashActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_splash)

        // 텍스트 애니메이션 적용
        val appTitle: TextView = findViewById(R.id.appTitle)
        val fadeIn: Animation = AnimationUtils.loadAnimation(this, R.anim.fade_in)
        appTitle.startAnimation(fadeIn)

        // 2초 대기 후 MainActivity로 전환
        val splashTime = 2000L
        Handler(Looper.getMainLooper()).postDelayed({
            // 화면 전환
            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)

            // 액티비티 종료
            finish()
        }, splashTime)
    }
}
